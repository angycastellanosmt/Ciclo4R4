package co.edu.usa.ciclo4.retocuatro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RetocuatroApplicationTests {

	@Test
	void contextLoads() {
	}

}
